package sorting.simpleSorting;

import sorting.AbstractSorting;

/**
 * The bubble sort algorithm iterates over the array multiple times, pushing big
 * elements to the right by swapping adjacent elements, until the array is
 * sorted.
 */
public class BubbleSort<T extends Comparable<T>> extends AbstractSorting<T> {

	@Override
	public void sort(T[] array, int leftIndex, int rightIndex) {
		for (int r = rightIndex; r > 0; r--) {
			for (int l = leftIndex; l < r; l++) {
				if (array[l].compareTo(array[l+1]) == 1) {
					util.Util.swap(array, l, l+1);
				}
			}
		}
	}
}
